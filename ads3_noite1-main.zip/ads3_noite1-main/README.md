# AMASLGBT
Repositorio destinado a construção de um site para dar visibilidade das ações da organização

# Construção
Construido com HTML5, CSS e JS

# Dev's

- Jadeilson
- Eliel
- Vinicius
- Ana
- Carla

